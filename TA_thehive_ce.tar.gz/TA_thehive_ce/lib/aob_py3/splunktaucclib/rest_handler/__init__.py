"""
Custom REST Handler in Splunk add-on.
"""
